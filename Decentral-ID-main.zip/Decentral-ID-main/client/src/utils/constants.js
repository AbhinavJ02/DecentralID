import abi from './SmartContract.json';

export const contractABI = abi.abi;
export const contractAddress = '0x440A56F75A150bAdD27565792FCfDb23b3Dd73CA';

//IPFS
export const projectId = '2NTEjHeG4NfpOuXQtsMzDCN7aVy'
export const projectSecretKey = '9ac5a480614ba7885aabc99c9c3d45f4'