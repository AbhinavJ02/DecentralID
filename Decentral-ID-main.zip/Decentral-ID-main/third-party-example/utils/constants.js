const abi = require('./SmartContract.json');


module.exports = {
    contractABI: abi.abi,
    contractAddress: '0x440A56F75A150bAdD27565792FCfDb23b3Dd73CA'
}